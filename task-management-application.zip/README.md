# TaskFlow — Full-Stack Task Management Application

**Thiranex Internship — Task 2**

A full-stack task management web application with secure user registration & login, JWT authentication, user-isolated task CRUD operations, filtering/search/sorting, and real-time updates using Socket.IO.

---

## Tech Stack

- **Frontend:** React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons, Socket.IO Client
- **Backend:** Node.js, Express.js, TypeScript (`tsx`), Socket.IO
- **Authentication & Security:** `bcryptjs` password hashing, `jsonwebtoken` (JWT), ownership authorization middleware
- **Database:** MongoDB with Mongoose ODM (`users` and `tasks` collections)

---

## Project Structure

```text
arun-fullstack-task-management/
├── backend/
│   ├── config/
│   │   ├── auth.ts                # JWT sign/verify & environment secret handling
│   │   └── db.ts                  # MongoDB Atlas connection & preview fallback
│   ├── middleware/
│   │   ├── auth.ts                # Bearer JWT verification middleware
│   │   ├── errorHandler.ts        # 404 & global JSON error middleware
│   │   └── validate.ts            # Auth/task validation & rate limiting
│   ├── models/
│   │   ├── Task.ts                # Mongoose Task schema (userId ownership index)
│   │   └── User.ts                # Mongoose User schema
│   ├── realtime/
│   │   └── socketServer.ts        # Authenticated Socket.IO server & user rooms
│   ├── routes/
│   │   ├── authRoutes.ts          # /api/auth/register, login, logout, me
│   │   └── taskRoutes.ts          # Protected /api/tasks CRUD endpoints
│   ├── services/
│   │   └── taskStore.ts           # MongoDB & preview data access with ownership checks
│   ├── app.ts                     # Express app setup & CORS policy
│   └── server.ts                  # Standalone backend server entry (split deploy)
├── src/
│   ├── components/
│   │   ├── AuthScreen.tsx         # Sign In / Create Account interface
│   │   ├── Dashboard.tsx          # Protected workspace, KPIs, filters & task list
│   │   ├── DeleteConfirmModal.tsx # Confirmation dialog before deletion
│   │   ├── Sidebar.tsx            # Sidebar navigation, counts & user profile
│   │   ├── TaskDetailModal.tsx    # Full task details & quick actions
│   │   └── TaskFormModal.tsx      # Create / Edit task modal
│   ├── hooks/
│   │   ├── useTaskSocket.ts       # Real-time Socket.IO sync hook
│   │   └── useTheme.ts            # Light / Dark theme toggle hook
│   ├── services/
│   │   └── api.ts                 # Authenticated REST API client
│   ├── types/
│   │   └── task.ts                # Shared TypeScript interfaces
│   ├── App.tsx                    # Session state & protected view switching
│   ├── index.css                  # Tailwind CSS v4 configuration
│   └── main.tsx                   # React root mount
├── server.ts                      # Unified Express + Socket.IO + Vite server (port 3000)
├── .env.example                   # Environment variable template (no real secrets)
├── index.html                     # HTML entry & metadata
└── package.json                   # Scripts and dependencies
```

---

## REST API Endpoints

### Authentication (`/api/auth`)

| Method | Endpoint | Access | Description |
| --- | --- | --- | --- |
| `POST` | `/api/auth/register` | Public | Registers a new user (`bcrypt` hash) & issues JWT |
| `POST` | `/api/auth/login` | Public | Verifies credentials & issues JWT |
| `POST` | `/api/auth/logout` | Protected | Confirms user sign-out |
| `GET` | `/api/auth/me` | Protected | Returns authenticated user profile |

### Tasks (`/api/tasks`) — Protected (`Authorization: Bearer <token>`)

| Method | Endpoint | Description |
| --- | --- | --- |
| `GET` | `/api/tasks` | Lists only the authenticated user's tasks (`?status=`, `?priority=`, `?search=`, `?sort=`) |
| `GET` | `/api/tasks/:id` | Fetches single task details (enforces user ownership) |
| `POST` | `/api/tasks` | Creates a new task owned by the authenticated user & emits `task:created` |
| `PUT` / `PATCH` | `/api/tasks/:id` | Updates a task owned by the user & emits `task:updated` |
| `DELETE` | `/api/tasks/:id` | Deletes a task owned by the user & emits `task:deleted` |

---

## Real-Time Updates (Socket.IO)

- Clients authenticate during the Socket.IO handshake using `{ auth: { token } }`.
- The server verifies the JWT and places the socket into a private room (`user:<userId>`).
- Creating, updating, or deleting a task broadcasts `task:created`, `task:updated`, or `task:deleted` exclusively to that user's connected tabs so dashboards update immediately without manual refresh.
- On reconnection, the client automatically re-synchronizes with `/api/tasks`.

---

## Environment Variables

Copy `.env.example` to `.env` (never commit real secrets to GitHub):

```env
PORT=3000
MONGODB_URI=mongodb+srv://<username>:<password>@<cluster>.mongodb.net/task_manager?retryWrites=true&w=majority
JWT_SECRET=replace-with-a-long-random-secret
JWT_EXPIRES_IN=7d
FRONTEND_URL=https://your-frontend.vercel.app
VITE_API_URL=
```

---

## Installation & Running Locally

1. Install dependencies:
   ```bash
   npm install
   ```
2. Start development server (Express API + Socket.IO + Vite on port `3000`):
   ```bash
   npm run dev
   ```
3. Build production frontend bundle:
   ```bash
   npm run build
   ```
4. Start production server:
   ```bash
   npm start
   ```

---

## Deployment Guide (Chrome Only — No VS Code Required)

1. **GitHub (`arun-fullstack-task-management`):** Download the project ZIP from Google AI Studio, extract it, create a public GitHub repo named `arun-fullstack-task-management`, and upload all files (excluding `node_modules` and `.env`).
2. **MongoDB Atlas:** Create a free M0 cluster, add a database user, allow network access (`0.0.0.0/0`), and copy your `MONGODB_URI`.
3. **Render (Backend + Socket.IO):** Create a Web Service connected to `arun-fullstack-task-management`, Build Command `npm install`, Start Command `npx tsx backend/server.ts`, and configure `MONGODB_URI`, `JWT_SECRET`, and `FRONTEND_URL`.
4. **Vercel (Frontend):** Import `arun-fullstack-task-management` on Vercel (`npm run build`, output `dist`), set `VITE_API_URL` to your Render backend URL, and deploy.

---

## Screenshots

> Add screenshots inside a `screenshots/` directory before final submission:
> - `screenshots/login-register.png`
> - `screenshots/dashboard-light.png`
> - `screenshots/dashboard-dark.png`
> - `screenshots/task-modal.png`

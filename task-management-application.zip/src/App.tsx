import {useCallback, useState} from 'react';
import {AuthScreen} from './components/AuthScreen.tsx';
import {Dashboard} from './components/Dashboard.tsx';
import {useTheme} from './hooks/useTheme.ts';
import type {AuthUser} from './types/task.ts';

export default function App() {
  const {theme, toggleTheme} = useTheme();
  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<AuthUser | null>(null);

  const handleAuthenticated = useCallback((nextToken: string, nextUser: AuthUser) => {
    setToken(nextToken);
    setUser(nextUser);
  }, []);

  const handleLoggedOut = useCallback(() => {
    setToken(null);
    setUser(null);
  }, []);

  if (!token || !user) {
    return (
      <AuthScreen
        theme={theme}
        onToggleTheme={toggleTheme}
        onAuthenticated={handleAuthenticated}
      />
    );
  }

  return (
    <Dashboard
      token={token}
      user={user}
      theme={theme}
      onToggleTheme={toggleTheme}
      onLoggedOut={handleLoggedOut}
    />
  );
}

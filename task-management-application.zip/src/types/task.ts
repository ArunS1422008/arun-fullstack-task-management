export type TaskPriority = 'High' | 'Medium' | 'Low';
export type TaskStatus = 'pending' | 'completed';
export type TaskSortOrder = 'due-asc' | 'due-desc' | 'updated-desc';

export interface AuthUser {
  id: string;
  name: string;
  email: string;
  createdAt?: string;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  token: string;
  user: AuthUser;
}

export interface TaskItem {
  id: string;
  userId: string;
  title: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate: string;
  createdAt: string;
  updatedAt: string;
}

export interface TaskFormPayload {
  title: string;
  description: string;
  priority: TaskPriority;
  dueDate: string;
  status?: TaskStatus;
}

export interface TaskStats {
  total: number;
  pending: number;
  completed: number;
}

import {useEffect, useRef, useState} from 'react';
import {io, type Socket} from 'socket.io-client';
import {API_BASE} from '../services/api.ts';
import type {TaskItem} from '../types/task.ts';

interface UseTaskSocketOptions {
  token: string | null;
  onTaskCreated: (task: TaskItem) => void;
  onTaskUpdated: (task: TaskItem) => void;
  onTaskDeleted: (taskId: string) => void;
  onReconnectSync: () => void;
}

export function useTaskSocket({
  token,
  onTaskCreated,
  onTaskUpdated,
  onTaskDeleted,
  onReconnectSync,
}: UseTaskSocketOptions) {
  const [connected, setConnected] = useState(false);
  const hasConnectedOnceRef = useRef(false);

  const callbacksRef = useRef({
    onTaskCreated,
    onTaskUpdated,
    onTaskDeleted,
    onReconnectSync,
  });

  useEffect(() => {
    callbacksRef.current = {
      onTaskCreated,
      onTaskUpdated,
      onTaskDeleted,
      onReconnectSync,
    };
  }, [onTaskCreated, onTaskUpdated, onTaskDeleted, onReconnectSync]);

  useEffect(() => {
    if (!token) {
      setConnected(false);
      hasConnectedOnceRef.current = false;
      return;
    }

    const socketUrl = API_BASE || window.location.origin;
    const socket: Socket = io(socketUrl, {
      auth: {token},
      transports: ['websocket', 'polling'],
      reconnection: true,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
    });

    socket.on('connect', () => {
      setConnected(true);
      if (hasConnectedOnceRef.current) {
        callbacksRef.current.onReconnectSync();
      }
      hasConnectedOnceRef.current = true;
    });

    socket.on('disconnect', () => {
      setConnected(false);
    });

    socket.on('task:created', (payload: {task?: TaskItem}) => {
      if (payload?.task) {
        callbacksRef.current.onTaskCreated(payload.task);
      }
    });

    socket.on('task:updated', (payload: {task?: TaskItem}) => {
      if (payload?.task) {
        callbacksRef.current.onTaskUpdated(payload.task);
      }
    });

    socket.on('task:deleted', (payload: {taskId?: string}) => {
      if (payload?.taskId) {
        callbacksRef.current.onTaskDeleted(payload.taskId);
      }
    });

    return () => {
      socket.disconnect();
      setConnected(false);
    };
  }, [token]);

  return {connected};
}

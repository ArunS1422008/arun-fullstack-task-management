import type {
  AuthResponse,
  AuthUser,
  TaskFormPayload,
  TaskItem,
  TaskPriority,
  TaskSortOrder,
  TaskStatus,
} from '../types/task.ts';

export const API_BASE = (import.meta.env.VITE_API_URL || '').replace(/\/$/, '');

async function parseResponse<T>(response: Response): Promise<T> {
  const contentType = response.headers.get('content-type') || '';
  if (!contentType.includes('application/json')) {
    throw new Error('Unexpected response format from server.');
  }
  const payload = await response.json();
  if (!response.ok) {
    const message =
      typeof payload?.message === 'string'
        ? payload.message
        : `Request failed with status ${response.status}`;
    const err = new Error(message) as Error & {
      status?: number;
      fieldErrors?: Record<string, string>;
    };
    err.status = response.status;
    if (payload?.errors && typeof payload.errors === 'object') {
      err.fieldErrors = payload.errors as Record<string, string>;
    }
    throw err;
  }
  return payload as T;
}

export async function registerAccount(input: {
  name: string;
  email: string;
  password: string;
}): Promise<AuthResponse> {
  const response = await fetch(`${API_BASE}/api/auth/register`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify(input),
  });
  return parseResponse<AuthResponse>(response);
}

export async function loginAccount(input: {
  email: string;
  password: string;
}): Promise<AuthResponse> {
  const response = await fetch(`${API_BASE}/api/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Accept: 'application/json',
    },
    body: JSON.stringify(input),
  });
  return parseResponse<AuthResponse>(response);
}

export async function logoutAccount(token: string): Promise<void> {
  await fetch(`${API_BASE}/api/auth/logout`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
  });
}

export async function fetchCurrentUser(token: string): Promise<AuthUser> {
  const response = await fetch(`${API_BASE}/api/auth/me`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
  });
  const result = await parseResponse<{success: boolean; user: AuthUser}>(response);
  return result.user;
}

export interface FetchTasksParams {
  status?: TaskStatus | 'all';
  priority?: TaskPriority | 'all';
  search?: string;
  sort?: TaskSortOrder;
}

export async function fetchTasks(
  token: string,
  params: FetchTasksParams = {},
): Promise<TaskItem[]> {
  const searchParams = new URLSearchParams();
  if (params.status && params.status !== 'all') {
    searchParams.set('status', params.status);
  }
  if (params.priority && params.priority !== 'all') {
    searchParams.set('priority', params.priority);
  }
  if (params.search && params.search.trim()) {
    searchParams.set('search', params.search.trim());
  }
  if (params.sort) {
    searchParams.set('sort', params.sort);
  }

  const query = searchParams.toString();
  const response = await fetch(`${API_BASE}/api/tasks${query ? `?${query}` : ''}`, {
    method: 'GET',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
  });
  const result = await parseResponse<{success: boolean; data: TaskItem[]}>(response);
  return result.data;
}

export async function createTask(token: string, payload: TaskFormPayload): Promise<TaskItem> {
  const response = await fetch(`${API_BASE}/api/tasks`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const result = await parseResponse<{success: boolean; data: TaskItem}>(response);
  return result.data;
}

export async function updateTask(
  token: string,
  id: string,
  payload: Partial<TaskFormPayload>,
): Promise<TaskItem> {
  const response = await fetch(`${API_BASE}/api/tasks/${encodeURIComponent(id)}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
    body: JSON.stringify(payload),
  });
  const result = await parseResponse<{success: boolean; data: TaskItem}>(response);
  return result.data;
}

export async function deleteTask(token: string, id: string): Promise<string> {
  const response = await fetch(`${API_BASE}/api/tasks/${encodeURIComponent(id)}`, {
    method: 'DELETE',
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: 'application/json',
    },
  });
  const result = await parseResponse<{success: boolean; deletedId: string}>(response);
  return result.deletedId;
}

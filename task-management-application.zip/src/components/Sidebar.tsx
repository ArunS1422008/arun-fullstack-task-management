import {
  AlertTriangle,
  CheckCircle2,
  CheckSquare,
  Clock,
  Flag,
  Layers,
  LogOut,
  X,
} from 'lucide-react';
import type {AuthUser, TaskPriority, TaskStatus} from '../types/task.ts';

export type SidebarFilterId =
  | 'all'
  | 'pending'
  | 'completed'
  | 'priority-High'
  | 'priority-Medium'
  | 'priority-Low';

interface SidebarProps {
  user: AuthUser;
  activeView: SidebarFilterId;
  counts: {
    all: number;
    pending: number;
    completed: number;
    high: number;
    medium: number;
    low: number;
  };
  mobileOpen: boolean;
  onCloseMobile: () => void;
  onSelectView: (view: SidebarFilterId) => void;
  onLogout: () => void;
}

export function getSidebarSelectionLabel(view: SidebarFilterId): string {
  switch (view) {
    case 'pending':
      return 'Pending Tasks';
    case 'completed':
      return 'Completed Tasks';
    case 'priority-High':
      return 'High Priority';
    case 'priority-Medium':
      return 'Medium Priority';
    case 'priority-Low':
      return 'Low Priority';
    default:
      return 'All Tasks';
  }
}

export function parseSidebarView(view: SidebarFilterId): {
  status: TaskStatus | 'all';
  priority: TaskPriority | 'all';
} {
  if (view === 'pending' || view === 'completed') {
    return {status: view, priority: 'all'};
  }
  if (view === 'priority-High') {
    return {status: 'all', priority: 'High'};
  }
  if (view === 'priority-Medium') {
    return {status: 'all', priority: 'Medium'};
  }
  if (view === 'priority-Low') {
    return {status: 'all', priority: 'Low'};
  }
  return {status: 'all', priority: 'all'};
}

function getInitials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) {
    return 'U';
  }
  if (parts.length === 1) {
    return parts[0].slice(0, 2).toUpperCase();
  }
  return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
}

export function Sidebar({
  user,
  activeView,
  counts,
  mobileOpen,
  onCloseMobile,
  onSelectView,
  onLogout,
}: SidebarProps) {
  const taskViews: Array<{
    id: SidebarFilterId;
    label: string;
    count: number;
    icon: typeof Layers;
  }> = [
    {id: 'all', label: 'All Tasks', count: counts.all, icon: Layers},
    {id: 'pending', label: 'Pending Tasks', count: counts.pending, icon: Clock},
    {id: 'completed', label: 'Completed Tasks', count: counts.completed, icon: CheckCircle2},
  ];

  const priorityViews: Array<{
    id: SidebarFilterId;
    label: string;
    count: number;
    icon: typeof Flag;
    iconClass: string;
  }> = [
    {
      id: 'priority-High',
      label: 'High Priority',
      count: counts.high,
      icon: AlertTriangle,
      iconClass: 'text-red-600 dark:text-red-400',
    },
    {
      id: 'priority-Medium',
      label: 'Medium Priority',
      count: counts.medium,
      icon: Flag,
      iconClass: 'text-amber-600 dark:text-amber-400',
    },
    {
      id: 'priority-Low',
      label: 'Low Priority',
      count: counts.low,
      icon: Flag,
      iconClass: 'text-emerald-600 dark:text-emerald-400',
    },
  ];

  const content = (
    <div className="flex h-full flex-col justify-between bg-white dark:bg-zinc-950">
      <div>
        {/* Brand */}
        <div className="flex h-16 items-center justify-between border-b border-slate-200 px-5 dark:border-zinc-800">
          <div className="flex items-center gap-2.5">
            <CheckSquare className="h-5 w-5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
            <span className="text-base font-bold tracking-tight text-slate-950 dark:text-zinc-50">
              TaskFlow
            </span>
          </div>

          <button
            type="button"
            onClick={onCloseMobile}
            aria-label="Close navigation sidebar"
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 lg:hidden dark:text-zinc-400 dark:hover:bg-zinc-900 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Navigation Groups */}
        <nav aria-label="Task workspace views" className="space-y-6 p-4">
          <div>
            <p className="px-2.5 text-xs font-semibold text-slate-500 dark:text-zinc-400">
              Overview
            </p>
            <ul className="mt-2 space-y-1">
              {taskViews.map((item) => {
                const Icon = item.icon;
                const active = activeView === item.id;
                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectView(item.id);
                        onCloseMobile();
                      }}
                      className={`flex min-h-10 w-full items-center justify-between rounded-lg px-2.5 py-2 text-sm font-medium transition-colors ${
                        active
                          ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                          : 'text-slate-700 hover:bg-slate-100 hover:text-slate-950 dark:text-zinc-300 dark:hover:bg-zinc-900 dark:hover:text-white'
                      }`}
                    >
                      <span className="flex items-center gap-2.5 truncate">
                        <Icon className="h-4 w-4 shrink-0" aria-hidden="true" />
                        <span className="truncate">{item.label}</span>
                      </span>
                      <span className="ml-2 font-mono text-xs tabular-nums text-slate-500 dark:text-zinc-400">
                        {item.count}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>

          <div>
            <p className="px-2.5 text-xs font-semibold text-slate-500 dark:text-zinc-400">
              By Priority
            </p>
            <ul className="mt-2 space-y-1">
              {priorityViews.map((item) => {
                const Icon = item.icon;
                const active = activeView === item.id;
                return (
                  <li key={item.id}>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectView(item.id);
                        onCloseMobile();
                      }}
                      className={`flex min-h-10 w-full items-center justify-between rounded-lg px-2.5 py-2 text-sm font-medium transition-colors ${
                        active
                          ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300'
                          : 'text-slate-700 hover:bg-slate-100 hover:text-slate-950 dark:text-zinc-300 dark:hover:bg-zinc-900 dark:hover:text-white'
                      }`}
                    >
                      <span className="flex items-center gap-2.5 truncate">
                        <Icon className={`h-4 w-4 shrink-0 ${item.iconClass}`} aria-hidden="true" />
                        <span className="truncate">{item.label}</span>
                      </span>
                      <span className="ml-2 font-mono text-xs tabular-nums text-slate-500 dark:text-zinc-400">
                        {item.count}
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </nav>
      </div>

      {/* User Profile Section */}
      <div className="border-t border-slate-200 p-4 dark:border-zinc-800">
        <div className="flex items-center gap-3">
          <div
            aria-hidden="true"
            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-slate-900 text-xs font-semibold text-white dark:bg-zinc-100 dark:text-zinc-950"
          >
            {getInitials(user.name)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate text-sm font-semibold text-slate-950 dark:text-zinc-100">
              {user.name}
            </p>
            <p className="truncate text-xs text-slate-500 dark:text-zinc-400">{user.email}</p>
          </div>
        </div>

        <button
          type="button"
          onClick={onLogout}
          className="mt-3 flex min-h-10 w-full items-center justify-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-100 hover:text-slate-950 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800 dark:hover:text-white"
        >
          <LogOut className="h-3.5 w-3.5" aria-hidden="true" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Sidebar */}
      <aside className="hidden w-64 shrink-0 border-r border-slate-200 lg:block dark:border-zinc-800">
        <div className="sticky top-0 h-screen">{content}</div>
      </aside>

      {/* Mobile Slide-Over Sidebar */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-zinc-950/60 backdrop-blur-sm"
            onClick={onCloseMobile}
            aria-hidden="true"
          />
          <aside className="relative z-10 h-full w-72 max-w-[85vw] border-r border-slate-200 dark:border-zinc-800">
            {content}
          </aside>
        </div>
      )}
    </>
  );
}

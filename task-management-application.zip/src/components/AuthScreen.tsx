import {
  AlertCircle,
  CheckSquare,
  Eye,
  EyeOff,
  Loader2,
  Lock,
  Moon,
  RefreshCw,
  ShieldCheck,
  Sun,
} from 'lucide-react';
import {useState, type FormEvent} from 'react';
import type {ThemeMode} from '../hooks/useTheme.ts';
import {loginAccount, registerAccount} from '../services/api.ts';
import type {AuthUser} from '../types/task.ts';

interface AuthScreenProps {
  theme: ThemeMode;
  onToggleTheme: () => void;
  onAuthenticated: (token: string, user: AuthUser) => void;
}

type AuthMode = 'login' | 'register';

export function AuthScreen({theme, onToggleTheme, onAuthenticated}: AuthScreenProps) {
  const [mode, setMode] = useState<AuthMode>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  const switchMode = (nextMode: AuthMode) => {
    setMode(nextMode);
    setErrorMessage(null);
    setFieldErrors({});
  };

  const validate = (): boolean => {
    const errors: Record<string, string> = {};
    if (mode === 'register' && name.trim().length < 2) {
      errors.name = 'Name must be at least 2 characters.';
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
      errors.email = 'Please enter a valid email address.';
    }
    if (password.length < (mode === 'register' ? 6 : 1)) {
      errors.password =
        mode === 'register'
          ? 'Password must be at least 6 characters.'
          : 'Please enter your password.';
    }
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage(null);

    if (!validate()) {
      return;
    }

    setSubmitting(true);
    try {
      if (mode === 'register') {
        const result = await registerAccount({
          name: name.trim(),
          email: email.trim(),
          password,
        });
        onAuthenticated(result.token, result.user);
      } else {
        const result = await loginAccount({
          email: email.trim(),
          password,
        });
        onAuthenticated(result.token, result.user);
      }
    } catch (error) {
      const typed = error as Error & {fieldErrors?: Record<string, string>};
      if (typed.fieldErrors) {
        setFieldErrors(typed.fieldErrors);
      }
      setErrorMessage(typed.message || 'Authentication failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-slate-50 text-slate-900 transition-colors duration-200 dark:bg-zinc-950 dark:text-zinc-100">
      {/* Clean top bar */}
      <header className="border-b border-slate-200 bg-white dark:border-zinc-800 dark:bg-zinc-950">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4 sm:px-6 lg:px-8">
          <div className="flex items-center gap-2.5">
            <CheckSquare className="h-5 w-5 text-blue-600 dark:text-blue-400" aria-hidden="true" />
            <span className="text-lg font-bold tracking-tight">TaskFlow</span>
          </div>

          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            className="inline-flex min-h-10 items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800"
          >
            {theme === 'dark' ? (
              <>
                <Sun className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Light Mode</span>
              </>
            ) : (
              <>
                <Moon className="h-3.5 w-3.5" aria-hidden="true" />
                <span>Dark Mode</span>
              </>
            )}
          </button>
        </div>
      </header>

      <main className="mx-auto flex w-full max-w-6xl flex-1 items-center px-4 py-10 sm:px-6 lg:px-8">
        <div className="grid w-full items-center gap-10 lg:grid-cols-12 lg:gap-16">
          {/* Left column: workspace overview */}
          <div className="lg:col-span-6">
            <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">
              Task Management Workspace
            </p>
            <h1
              className="mt-3 max-w-xl text-balance font-semibold tracking-tight text-slate-950 dark:text-zinc-50"
              style={{fontSize: 'clamp(2rem, 3.6vw, 3rem)', lineHeight: 1.1}}
            >
              Organize priorities, track deadlines, and stay synchronized.
            </h1>
            <p className="mt-4 max-w-lg text-base leading-relaxed text-slate-600 dark:text-zinc-300">
              A full-stack MERN task manager featuring private user accounts, JWT authentication,
              priority &amp; due-date filtering, and instant real-time updates over Socket.IO.
            </p>

            <div className="mt-8 divide-y divide-slate-200 border-t border-slate-200 dark:divide-zinc-800 dark:border-zinc-800">
              <div className="flex items-start gap-3.5 py-4">
                <ShieldCheck
                  className="mt-0.5 h-5 w-5 shrink-0 text-blue-600 dark:text-blue-400"
                  aria-hidden="true"
                />
                <div>
                  <h2 className="text-sm font-semibold text-slate-900 dark:text-zinc-100">
                    Private User Ownership
                  </h2>
                  <p className="mt-0.5 text-sm text-slate-600 dark:text-zinc-400">
                    Bcrypt password hashing and JWT route verification ensure your tasks stay
                    accessible only to your account.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 py-4">
                <RefreshCw
                  className="mt-0.5 h-5 w-5 shrink-0 text-blue-600 dark:text-blue-400"
                  aria-hidden="true"
                />
                <div>
                  <h2 className="text-sm font-semibold text-slate-900 dark:text-zinc-100">
                    Real-Time Socket.IO Sync
                  </h2>
                  <p className="mt-0.5 text-sm text-slate-600 dark:text-zinc-400">
                    Creating, editing, or completing a task updates your dashboard immediately
                    without manual page refreshes.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3.5 py-4">
                <Lock
                  className="mt-0.5 h-5 w-5 shrink-0 text-blue-600 dark:text-blue-400"
                  aria-hidden="true"
                />
                <div>
                  <h2 className="text-sm font-semibold text-slate-900 dark:text-zinc-100">
                    Structured Filtering &amp; Due Dates
                  </h2>
                  <p className="mt-0.5 text-sm text-slate-600 dark:text-zinc-400">
                    Search across titles and notes, filter by status or priority, and sort tasks by
                    upcoming due dates.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right column: Auth Card */}
          <div className="lg:col-span-6">
            <div className="mx-auto max-w-md rounded-2xl border border-slate-200 bg-white p-6 sm:p-8 dark:border-zinc-800 dark:bg-zinc-900">
              {/* Segmented mode switcher */}
              <div
                role="tablist"
                aria-label="Authentication mode"
                className="grid grid-cols-2 gap-1 rounded-lg border border-slate-200 bg-slate-100 p-1 dark:border-zinc-800 dark:bg-zinc-950"
              >
                <button
                  type="button"
                  role="tab"
                  aria-selected={mode === 'login'}
                  onClick={() => switchMode('login')}
                  className={`rounded-md py-2 text-sm font-semibold transition-colors ${
                    mode === 'login'
                      ? 'bg-white text-slate-950 shadow-sm dark:bg-zinc-800 dark:text-white'
                      : 'text-slate-600 hover:text-slate-950 dark:text-zinc-400 dark:hover:text-white'
                  }`}
                >
                  Sign In
                </button>
                <button
                  type="button"
                  role="tab"
                  aria-selected={mode === 'register'}
                  onClick={() => switchMode('register')}
                  className={`rounded-md py-2 text-sm font-semibold transition-colors ${
                    mode === 'register'
                      ? 'bg-white text-slate-950 shadow-sm dark:bg-zinc-800 dark:text-white'
                      : 'text-slate-600 hover:text-slate-950 dark:text-zinc-400 dark:hover:text-white'
                  }`}
                >
                  Create Account
                </button>
              </div>

              <div className="mt-6">
                <h2 className="text-xl font-semibold text-slate-950 dark:text-zinc-50">
                  {mode === 'login' ? 'Welcome back' : 'Create your workspace account'}
                </h2>
                <p className="mt-1 text-sm text-slate-600 dark:text-zinc-400">
                  {mode === 'login'
                    ? 'Enter your credentials to access your task dashboard.'
                    : 'Register to start creating and tracking your personal tasks.'}
                </p>
              </div>

              <form onSubmit={handleSubmit} noValidate className="mt-6 space-y-4">
                {mode === 'register' && (
                  <div>
                    <label
                      htmlFor="auth-name"
                      className="block text-sm font-medium text-slate-900 dark:text-zinc-100"
                    >
                      Full Name
                    </label>
                    <input
                      id="auth-name"
                      type="text"
                      autoComplete="name"
                      required
                      value={name}
                      onChange={(event) => {
                        setName(event.target.value);
                        if (fieldErrors.name) {
                          setFieldErrors((prev) => ({...prev, name: ''}));
                        }
                      }}
                      placeholder="Arun S"
                      className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-950 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100 dark:placeholder:text-zinc-500"
                    />
                    {fieldErrors.name && (
                      <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                        {fieldErrors.name}
                      </p>
                    )}
                  </div>
                )}

                <div>
                  <label
                    htmlFor="auth-email"
                    className="block text-sm font-medium text-slate-900 dark:text-zinc-100"
                  >
                    Email Address
                  </label>
                  <input
                    id="auth-email"
                    type="email"
                    autoComplete="email"
                    required
                    value={email}
                    onChange={(event) => {
                      setEmail(event.target.value);
                      if (fieldErrors.email) {
                        setFieldErrors((prev) => ({...prev, email: ''}));
                      }
                    }}
                    placeholder="you@example.com"
                    className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-950 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100 dark:placeholder:text-zinc-500"
                  />
                  {fieldErrors.email && (
                    <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                      {fieldErrors.email}
                    </p>
                  )}
                </div>

                <div>
                  <label
                    htmlFor="auth-password"
                    className="block text-sm font-medium text-slate-900 dark:text-zinc-100"
                  >
                    Password
                  </label>
                  <div className="relative mt-1.5">
                    <input
                      id="auth-password"
                      type={showPassword ? 'text' : 'password'}
                      autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                      required
                      value={password}
                      onChange={(event) => {
                        setPassword(event.target.value);
                        if (fieldErrors.password) {
                          setFieldErrors((prev) => ({...prev, password: ''}));
                        }
                      }}
                      placeholder={
                        mode === 'register' ? 'Minimum 6 characters' : 'Enter your password'
                      }
                      className="block w-full rounded-lg border border-slate-300 bg-white py-2.5 pl-3.5 pr-11 text-sm text-slate-950 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-950 dark:text-zinc-100 dark:placeholder:text-zinc-500"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((prev) => !prev)}
                      aria-label={showPassword ? 'Hide password' : 'Show password'}
                      className="absolute inset-y-0 right-0 flex w-10 items-center justify-center text-slate-500 hover:text-slate-900 dark:text-zinc-400 dark:hover:text-zinc-100"
                    >
                      {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                    </button>
                  </div>
                  {fieldErrors.password && (
                    <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                      {fieldErrors.password}
                    </p>
                  )}
                </div>

                {errorMessage && (
                  <div
                    role="alert"
                    className="flex items-start gap-2.5 rounded-xl border border-red-200 bg-red-50 p-3.5 text-sm text-red-900 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-200"
                  >
                    <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600 dark:text-red-400" />
                    <span>{errorMessage}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-lg bg-blue-600 px-4 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-blue-700 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-blue-500 dark:hover:bg-blue-600"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                      <span>
                        {mode === 'login' ? 'Signing in...' : 'Creating account...'}
                      </span>
                    </>
                  ) : (
                    <span>{mode === 'login' ? 'Sign In' : 'Create Account'}</span>
                  )}
                </button>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

import {AlertCircle, Loader2, X} from 'lucide-react';
import {useEffect, useState, type FormEvent} from 'react';
import type {TaskFormPayload, TaskItem, TaskPriority, TaskStatus} from '../types/task.ts';

interface TaskFormModalProps {
  open: boolean;
  editingTask: TaskItem | null;
  onClose: () => void;
  onSubmit: (payload: TaskFormPayload, taskId?: string) => Promise<void>;
}

function getTodayDateString(): string {
  return new Date().toISOString().slice(0, 10);
}

export function TaskFormModal({open, editingTask, onClose, onSubmit}: TaskFormModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [priority, setPriority] = useState<TaskPriority>('Medium');
  const [dueDate, setDueDate] = useState(getTodayDateString());
  const [status, setStatus] = useState<TaskStatus>('pending');
  const [submitting, setSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) {
      return;
    }
    if (editingTask) {
      setTitle(editingTask.title);
      setDescription(editingTask.description);
      setPriority(editingTask.priority);
      setDueDate(editingTask.dueDate);
      setStatus(editingTask.status);
    } else {
      setTitle('');
      setDescription('');
      setPriority('Medium');
      setDueDate(getTodayDateString());
      setStatus('pending');
    }
    setErrorMessage(null);
    setFieldErrors({});
  }, [open, editingTask]);

  useEffect(() => {
    if (!open) {
      return;
    }
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !submitting) {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [open, submitting, onClose]);

  if (!open) {
    return null;
  }

  const validate = (): boolean => {
    const errors: Record<string, string> = {};
    if (title.trim().length < 2 || title.trim().length > 120) {
      errors.title = 'Task title must be between 2 and 120 characters.';
    }
    if (description.trim().length > 1000) {
      errors.description = 'Description cannot exceed 1000 characters.';
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dueDate)) {
      errors.dueDate = 'Please select a valid due date.';
    }
    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setErrorMessage(null);

    if (!validate()) {
      return;
    }

    setSubmitting(true);
    try {
      await onSubmit(
        {
          title: title.trim(),
          description: description.trim(),
          priority,
          dueDate,
          ...(editingTask ? {status} : {}),
        },
        editingTask?.id,
      );
      onClose();
    } catch (error) {
      const typed = error as Error & {fieldErrors?: Record<string, string>};
      if (typed.fieldErrors) {
        setFieldErrors(typed.fieldErrors);
      }
      setErrorMessage(typed.message || 'Unable to save task. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="task-form-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/65 p-4 backdrop-blur-sm"
      onClick={() => {
        if (!submitting) {
          onClose();
        }
      }}
    >
      <div
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-zinc-800 dark:bg-zinc-950"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-center justify-between gap-4 border-b border-slate-200 pb-4 dark:border-zinc-800">
          <div>
            <h2
              id="task-form-modal-title"
              className="text-lg font-semibold text-slate-950 dark:text-zinc-50"
            >
              {editingTask ? 'Edit Task' : 'Create New Task'}
            </h2>
            <p className="mt-0.5 text-xs text-slate-500 dark:text-zinc-400">
              {editingTask
                ? 'Update task details, priority, status, or due date.'
                : 'Add a new task to your personal workspace.'}
            </p>
          </div>
          <button
            type="button"
            disabled={submitting}
            onClick={onClose}
            aria-label="Close task form"
            className="inline-flex h-10 w-10 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-zinc-400 dark:hover:bg-zinc-900 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} noValidate className="mt-5 space-y-4">
          <div>
            <label
              htmlFor="task-title"
              className="block text-sm font-medium text-slate-900 dark:text-zinc-100"
            >
              Task Title
            </label>
            <input
              id="task-title"
              type="text"
              required
              value={title}
              onChange={(event) => {
                setTitle(event.target.value);
                if (fieldErrors.title) {
                  setFieldErrors((prev) => ({...prev, title: ''}));
                }
              }}
              placeholder="e.g., Complete MongoDB schema validation"
              className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-950 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:placeholder:text-zinc-500"
            />
            {fieldErrors.title && (
              <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                {fieldErrors.title}
              </p>
            )}
          </div>

          <div>
            <label
              htmlFor="task-description"
              className="block text-sm font-medium text-slate-900 dark:text-zinc-100"
            >
              Description
            </label>
            <textarea
              id="task-description"
              rows={3}
              value={description}
              onChange={(event) => {
                setDescription(event.target.value);
                if (fieldErrors.description) {
                  setFieldErrors((prev) => ({...prev, description: ''}));
                }
              }}
              placeholder="Add notes, acceptance criteria, or subtasks..."
              className="mt-1.5 block w-full resize-y rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-950 placeholder:text-slate-400 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:placeholder:text-zinc-500"
            />
            {fieldErrors.description && (
              <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                {fieldErrors.description}
              </p>
            )}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label
                htmlFor="task-priority"
                className="block text-sm font-medium text-slate-900 dark:text-zinc-100"
              >
                Priority
              </label>
              <select
                id="task-priority"
                value={priority}
                onChange={(event) => setPriority(event.target.value as TaskPriority)}
                className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-950 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
              >
                <option value="High">High</option>
                <option value="Medium">Medium</option>
                <option value="Low">Low</option>
              </select>
            </div>

            <div>
              <label
                htmlFor="task-due-date"
                className="block text-sm font-medium text-slate-900 dark:text-zinc-100"
              >
                Due Date
              </label>
              <input
                id="task-due-date"
                type="date"
                required
                value={dueDate}
                onChange={(event) => {
                  setDueDate(event.target.value);
                  if (fieldErrors.dueDate) {
                    setFieldErrors((prev) => ({...prev, dueDate: ''}));
                  }
                }}
                className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 font-mono text-sm tabular-nums text-slate-950 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
              />
              {fieldErrors.dueDate && (
                <p className="mt-1 text-xs font-medium text-red-600 dark:text-red-400">
                  {fieldErrors.dueDate}
                </p>
              )}
            </div>
          </div>

          {editingTask && (
            <div>
              <label
                htmlFor="task-status"
                className="block text-sm font-medium text-slate-900 dark:text-zinc-100"
              >
                Status
              </label>
              <select
                id="task-status"
                value={status}
                onChange={(event) => setStatus(event.target.value as TaskStatus)}
                className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-slate-950 focus:border-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100"
              >
                <option value="pending">Pending</option>
                <option value="completed">Completed</option>
              </select>
            </div>
          )}

          {errorMessage && (
            <div
              role="alert"
              className="flex items-start gap-2.5 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-900 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-200"
            >
              <AlertCircle className="mt-0.5 h-4 w-4 shrink-0 text-red-600 dark:text-red-400" />
              <span>{errorMessage}</span>
            </div>
          )}

          <div className="flex items-center justify-end gap-3 border-t border-slate-200 pt-4 dark:border-zinc-800">
            <button
              type="button"
              disabled={submitting}
              onClick={onClose}
              className="inline-flex min-h-10 items-center justify-center rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={submitting}
              className="inline-flex min-h-10 items-center justify-center gap-2 rounded-lg bg-blue-600 px-5 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-60 dark:bg-blue-500 dark:hover:bg-blue-600"
            >
              {submitting ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" aria-hidden="true" />
                  <span>Saving...</span>
                </>
              ) : (
                <span>{editingTask ? 'Save Changes' : 'Create Task'}</span>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

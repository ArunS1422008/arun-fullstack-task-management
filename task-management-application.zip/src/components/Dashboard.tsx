import {
  AlertCircle,
  AlertTriangle,
  Calendar,
  Check,
  CheckCircle2,
  Clock,
  Edit3,
  Eye,
  Flag,
  Menu,
  Moon,
  Plus,
  RefreshCw,
  Search,
  Sun,
  Trash2,
  Wifi,
  WifiOff,
} from 'lucide-react';
import {useCallback, useEffect, useMemo, useState} from 'react';
import {useTaskSocket} from '../hooks/useTaskSocket.ts';
import type {ThemeMode} from '../hooks/useTheme.ts';
import {
  createTask,
  deleteTask,
  fetchTasks,
  logoutAccount,
  updateTask,
} from '../services/api.ts';
import type {
  AuthUser,
  TaskFormPayload,
  TaskItem,
  TaskPriority,
  TaskSortOrder,
  TaskStatus,
} from '../types/task.ts';
import {DeleteConfirmModal} from './DeleteConfirmModal.tsx';
import {
  Sidebar,
  getSidebarSelectionLabel,
  parseSidebarView,
  type SidebarFilterId,
} from './Sidebar.tsx';
import {TaskDetailModal} from './TaskDetailModal.tsx';
import {TaskFormModal} from './TaskFormModal.tsx';

interface DashboardProps {
  token: string;
  user: AuthUser;
  theme: ThemeMode;
  onToggleTheme: () => void;
  onLoggedOut: () => void;
}

function isOverdue(task: TaskItem): boolean {
  if (task.status === 'completed') {
    return false;
  }
  const today = new Date().toISOString().slice(0, 10);
  return task.dueDate < today;
}

export function Dashboard({
  token,
  user,
  theme,
  onToggleTheme,
  onLoggedOut,
}: DashboardProps) {
  const [tasks, setTasks] = useState<TaskItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [sidebarView, setSidebarView] = useState<SidebarFilterId>('all');
  const [statusFilter, setStatusFilter] = useState<TaskStatus | 'all'>('all');
  const [priorityFilter, setPriorityFilter] = useState<TaskPriority | 'all'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<TaskSortOrder>('due-asc');

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formOpen, setFormOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<TaskItem | null>(null);
  const [detailTask, setDetailTask] = useState<TaskItem | null>(null);
  const [deletingTask, setDeletingTask] = useState<TaskItem | null>(null);
  const [deletingInFlight, setDeletingInFlight] = useState(false);
  const [bannerFeedback, setBannerFeedback] = useState<{
    type: 'success' | 'error';
    text: string;
  } | null>(null);

  const loadAllTasks = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await fetchTasks(token, {sort: sortOrder});
      setTasks(data);
    } catch (err) {
      const typed = err as Error & {status?: number};
      if (typed.status === 401) {
        onLoggedOut();
        return;
      }
      setError(typed.message || 'Failed to load your tasks.');
    } finally {
      setLoading(false);
    }
  }, [token, sortOrder, onLoggedOut]);

  useEffect(() => {
    void loadAllTasks();
  }, [loadAllTasks]);

  const handleTaskCreatedRealtime = useCallback((created: TaskItem) => {
    setTasks((prev) => {
      if (prev.some((item) => item.id === created.id)) {
        return prev;
      }
      return [created, ...prev];
    });
  }, []);

  const handleTaskUpdatedRealtime = useCallback((updated: TaskItem) => {
    setTasks((prev) => prev.map((item) => (item.id === updated.id ? updated : item)));
    setDetailTask((prev) => (prev && prev.id === updated.id ? updated : prev));
  }, []);

  const handleTaskDeletedRealtime = useCallback((taskId: string) => {
    setTasks((prev) => prev.filter((item) => item.id !== taskId));
    setDetailTask((prev) => (prev && prev.id === taskId ? null : prev));
  }, []);

  const {connected: socketConnected} = useTaskSocket({
    token,
    onTaskCreated: handleTaskCreatedRealtime,
    onTaskUpdated: handleTaskUpdatedRealtime,
    onTaskDeleted: handleTaskDeletedRealtime,
    onReconnectSync: loadAllTasks,
  });

  const handleSelectSidebarView = (view: SidebarFilterId) => {
    setSidebarView(view);
    const parsed = parseSidebarView(view);
    setStatusFilter(parsed.status);
    setPriorityFilter(parsed.priority);
  };

  const counts = useMemo(() => {
    let pending = 0;
    let completed = 0;
    let high = 0;
    let medium = 0;
    let low = 0;
    for (const task of tasks) {
      if (task.status === 'completed') {
        completed += 1;
      } else {
        pending += 1;
      }
      if (task.priority === 'High') {
        high += 1;
      } else if (task.priority === 'Medium') {
        medium += 1;
      } else {
        low += 1;
      }
    }
    return {
      all: tasks.length,
      pending,
      completed,
      high,
      medium,
      low,
    };
  }, [tasks]);

  const filteredTasks = useMemo(() => {
    const query = searchQuery.trim().toLowerCase();
    const list = tasks.filter((task) => {
      if (statusFilter !== 'all' && task.status !== statusFilter) {
        return false;
      }
      if (priorityFilter !== 'all' && task.priority !== priorityFilter) {
        return false;
      }
      if (query) {
        const matchesTitle = task.title.toLowerCase().includes(query);
        const matchesDesc = task.description.toLowerCase().includes(query);
        if (!matchesTitle && !matchesDesc) {
          return false;
        }
      }
      return true;
    });

    return [...list].sort((a, b) => {
      if (sortOrder === 'due-desc') {
        return b.dueDate.localeCompare(a.dueDate);
      }
      if (sortOrder === 'updated-desc') {
        return b.updatedAt.localeCompare(a.updatedAt);
      }
      return a.dueDate.localeCompare(b.dueDate);
    });
  }, [tasks, statusFilter, priorityFilter, searchQuery, sortOrder]);

  const showToast = (type: 'success' | 'error', text: string) => {
    setBannerFeedback({type, text});
    window.setTimeout(() => {
      setBannerFeedback((current) => (current?.text === text ? null : current));
    }, 3500);
  };

  const handleSaveTask = async (payload: TaskFormPayload, taskId?: string) => {
    if (taskId) {
      const updated = await updateTask(token, taskId, payload);
      handleTaskUpdatedRealtime(updated);
      showToast('success', `Updated "${updated.title}".`);
    } else {
      const created = await createTask(token, payload);
      handleTaskCreatedRealtime(created);
      showToast('success', `Created "${created.title}".`);
    }
  };

  const handleToggleStatus = async (task: TaskItem) => {
    const nextStatus: TaskStatus = task.status === 'completed' ? 'pending' : 'completed';
    try {
      const updated = await updateTask(token, task.id, {status: nextStatus});
      handleTaskUpdatedRealtime(updated);
      showToast(
        'success',
        nextStatus === 'completed'
          ? `Marked "${updated.title}" as completed.`
          : `Reopened "${updated.title}" as pending.`,
      );
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Could not update task status.');
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingTask) {
      return;
    }
    setDeletingInFlight(true);
    try {
      const deletedId = await deleteTask(token, deletingTask.id);
      handleTaskDeletedRealtime(deletedId);
      showToast('success', `Deleted "${deletingTask.title}".`);
      setDeletingTask(null);
    } catch (err) {
      showToast('error', err instanceof Error ? err.message : 'Could not delete task.');
    } finally {
      setDeletingInFlight(false);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutAccount(token);
    } catch {
      // Proceed with client logout regardless
    } finally {
      onLoggedOut();
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900 transition-colors duration-200 dark:bg-zinc-950 dark:text-zinc-100">
      <Sidebar
        user={user}
        activeView={sidebarView}
        counts={counts}
        mobileOpen={mobileMenuOpen}
        onCloseMobile={() => setMobileMenuOpen(false)}
        onSelectView={handleSelectSidebarView}
        onLogout={handleLogout}
      />

      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top Bar Contract: Breadcrumb on left + Theme & New Task action on right */}
        <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/95 backdrop-blur-md dark:border-zinc-800 dark:bg-zinc-950/95">
          <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-8">
            <div className="flex min-w-0 items-center gap-3">
              <button
                type="button"
                onClick={() => setMobileMenuOpen(true)}
                aria-label="Open navigation sidebar"
                className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-lg border border-slate-200 text-slate-700 hover:bg-slate-100 lg:hidden dark:border-zinc-800 dark:text-zinc-200 dark:hover:bg-zinc-900"
              >
                <Menu className="h-5 w-5" />
              </button>

              <div className="min-w-0">
                <p className="truncate text-sm font-semibold text-slate-950 dark:text-zinc-50">
                  <span className="text-slate-500 dark:text-zinc-400">Workspace / </span>
                  <span>{getSidebarSelectionLabel(sidebarView)}</span>
                </p>
              </div>
            </div>

            <div className="flex shrink-0 items-center gap-2.5">
              <span
                title={
                  socketConnected
                    ? 'Real-time updates connected via Socket.IO'
                    : 'Reconnecting real-time updates'
                }
                className="hidden items-center gap-1.5 text-xs font-medium text-slate-500 sm:inline-flex dark:text-zinc-400"
              >
                {socketConnected ? (
                  <>
                    <Wifi className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>Live Sync</span>
                  </>
                ) : (
                  <>
                    <WifiOff className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
                    <span>Syncing</span>
                  </>
                )}
              </span>

              <button
                type="button"
                onClick={onToggleTheme}
                aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
                className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 bg-slate-50 text-slate-700 transition-colors hover:bg-slate-100 dark:border-zinc-800 dark:bg-zinc-900 dark:text-zinc-200 dark:hover:bg-zinc-800"
              >
                {theme === 'dark' ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </button>

              <button
                type="button"
                onClick={() => {
                  setEditingTask(null);
                  setFormOpen(true);
                }}
                className="inline-flex min-h-10 shrink-0 items-center gap-1.5 whitespace-nowrap rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
              >
                <Plus className="h-4 w-4" aria-hidden="true" />
                <span>New Task</span>
              </button>
            </div>
          </div>
        </header>

        {/* Main Content Viewport */}
        <main className="mx-auto w-full max-w-6xl flex-1 space-y-6 px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
          {/* Action feedback banner */}
          {bannerFeedback && (
            <div
              role={bannerFeedback.type === 'error' ? 'alert' : 'status'}
              className={`flex items-center gap-2.5 rounded-xl border px-4 py-3 text-sm font-medium ${
                bannerFeedback.type === 'success'
                  ? 'border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-200'
                  : 'border-red-200 bg-red-50 text-red-900 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-200'
              }`}
            >
              {bannerFeedback.type === 'success' ? (
                <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
              ) : (
                <AlertCircle className="h-4 w-4 shrink-0 text-red-600 dark:text-red-400" />
              )}
              <span>{bannerFeedback.text}</span>
            </div>
          )}

          {/* Dashboard Overview KPI Cards */}
          <section aria-label="Task summary statistics" className="grid gap-4 sm:grid-cols-3">
            <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-zinc-800 dark:bg-zinc-900/70">
              <p className="text-xs font-medium text-slate-500 dark:text-zinc-400">Total Tasks</p>
              <p className="mt-2 font-mono text-3xl font-semibold tabular-nums text-slate-950 dark:text-zinc-50">
                {counts.all}
              </p>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-zinc-800 dark:bg-zinc-900/70">
              <p className="text-xs font-medium text-slate-500 dark:text-zinc-400">Pending Tasks</p>
              <p className="mt-2 font-mono text-3xl font-semibold tabular-nums text-amber-600 dark:text-amber-400">
                {counts.pending}
              </p>
            </div>

            <div className="rounded-xl border border-slate-200 bg-white p-5 dark:border-zinc-800 dark:bg-zinc-900/70">
              <p className="text-xs font-medium text-slate-500 dark:text-zinc-400">
                Completed Tasks
              </p>
              <p className="mt-2 font-mono text-3xl font-semibold tabular-nums text-emerald-600 dark:text-emerald-400">
                {counts.completed}
              </p>
            </div>
          </section>

          {/* Search, Filter & Sort Controls */}
          <section
            aria-label="Search and filter tasks"
            className="flex flex-col gap-3 rounded-xl border border-slate-200 bg-white p-4 dark:border-zinc-800 dark:bg-zinc-900/70 md:flex-row md:items-center"
          >
            <div className="relative flex-1">
              <Search
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                aria-hidden="true"
              />
              <input
                type="search"
                value={searchQuery}
                onChange={(event) => setSearchQuery(event.target.value)}
                placeholder="Search tasks by title or description..."
                aria-label="Search tasks"
                className="block min-h-10 w-full rounded-lg border border-slate-200 bg-slate-50 py-2 pl-9 pr-3 text-sm text-slate-950 placeholder:text-slate-400 focus:border-blue-600 focus:bg-white focus:outline-none focus:ring-2 focus:ring-blue-600/20 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-100 dark:placeholder:text-zinc-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2.5 sm:flex sm:flex-wrap sm:items-center">
              <select
                aria-label="Filter by status"
                value={statusFilter}
                onChange={(event) => {
                  const nextStatus = event.target.value as TaskStatus | 'all';
                  setStatusFilter(nextStatus);
                  setSidebarView(nextStatus === 'all' ? 'all' : nextStatus);
                }}
                className="min-h-10 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-800 focus:border-blue-600 focus:outline-none dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-200"
              >
                <option value="all">All Statuses</option>
                <option value="pending">Pending</option>
                <option value="completed">Completed</option>
              </select>

              <select
                aria-label="Filter by priority"
                value={priorityFilter}
                onChange={(event) => {
                  const nextPriority = event.target.value as TaskPriority | 'all';
                  setPriorityFilter(nextPriority);
                  if (nextPriority !== 'all') {
                    setSidebarView(`priority-${nextPriority}` as SidebarFilterId);
                  } else if (statusFilter === 'all') {
                    setSidebarView('all');
                  }
                }}
                className="min-h-10 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-800 focus:border-blue-600 focus:outline-none dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-200"
              >
                <option value="all">All Priorities</option>
                <option value="High">High Priority</option>
                <option value="Medium">Medium Priority</option>
                <option value="Low">Low Priority</option>
              </select>

              <select
                aria-label="Sort tasks"
                value={sortOrder}
                onChange={(event) => setSortOrder(event.target.value as TaskSortOrder)}
                className="col-span-2 min-h-10 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-800 focus:border-blue-600 focus:outline-none sm:col-span-1 dark:border-zinc-800 dark:bg-zinc-950 dark:text-zinc-200"
              >
                <option value="due-asc">Due Date: Earliest First</option>
                <option value="due-desc">Due Date: Latest First</option>
                <option value="updated-desc">Recently Updated</option>
              </select>
            </div>
          </section>

          {/* Task List Container */}
          <section
            aria-label="Task list"
            className="overflow-hidden rounded-xl border border-slate-200 bg-white dark:border-zinc-800 dark:bg-zinc-900/70"
          >
            {/* Loading State */}
            {loading && (
              <div className="divide-y divide-slate-200 dark:divide-zinc-800" aria-busy="true">
                {[0, 1, 2].map((row) => (
                  <div key={row} className="flex items-center justify-between gap-4 p-5">
                    <div className="flex flex-1 items-center gap-3.5">
                      <div className="h-5 w-5 animate-pulse rounded bg-slate-200 dark:bg-zinc-800" />
                      <div className="flex-1 space-y-2">
                        <div className="h-4 w-1/2 animate-pulse rounded bg-slate-200 dark:bg-zinc-800" />
                        <div className="h-3 w-3/4 animate-pulse rounded bg-slate-200 dark:bg-zinc-800" />
                      </div>
                    </div>
                    <div className="h-8 w-24 animate-pulse rounded bg-slate-200 dark:bg-zinc-800" />
                  </div>
                ))}
              </div>
            )}

            {/* Error State */}
            {!loading && error && (
              <div role="alert" className="p-8 text-center">
                <AlertCircle className="mx-auto h-7 w-7 text-red-600 dark:text-red-400" />
                <p className="mt-3 text-sm font-semibold text-slate-950 dark:text-zinc-50">
                  Unable to load tasks
                </p>
                <p className="mt-1 text-sm text-slate-600 dark:text-zinc-400">{error}</p>
                <button
                  type="button"
                  onClick={() => void loadAllTasks()}
                  className="mt-4 inline-flex min-h-10 items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>Retry</span>
                </button>
              </div>
            )}

            {/* Empty State */}
            {!loading && !error && filteredTasks.length === 0 && (
              <div className="px-6 py-14 text-center">
                <CheckCircle2
                  className="mx-auto h-8 w-8 text-slate-400 dark:text-zinc-600"
                  aria-hidden="true"
                />
                <h2 className="mt-3 text-base font-semibold text-slate-950 dark:text-zinc-50">
                  {tasks.length === 0 ? 'No tasks created yet' : 'No matching tasks found'}
                </h2>
                <p className="mx-auto mt-1 max-w-md text-sm text-slate-600 dark:text-zinc-400">
                  {tasks.length === 0
                    ? 'Create your first task with a priority level and due date to start tracking progress.'
                    : 'Try clearing your search input or switching status and priority filters.'}
                </p>
                <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
                  {tasks.length === 0 ? (
                    <button
                      type="button"
                      onClick={() => {
                        setEditingTask(null);
                        setFormOpen(true);
                      }}
                      className="inline-flex min-h-10 items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-sm font-semibold text-white hover:bg-blue-700"
                    >
                      <Plus className="h-4 w-4" />
                      <span>Create First Task</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        setSearchQuery('');
                        setStatusFilter('all');
                        setPriorityFilter('all');
                        setSidebarView('all');
                      }}
                      className="inline-flex min-h-10 items-center rounded-lg border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-800 hover:bg-slate-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800"
                    >
                      Reset Filters
                    </button>
                  )}
                </div>
              </div>
            )}

            {/* Populated Task Rows */}
            {!loading && !error && filteredTasks.length > 0 && (
              <ul className="divide-y divide-slate-200 dark:divide-zinc-800">
                {filteredTasks.map((task) => {
                  const overdue = isOverdue(task);
                  const completed = task.status === 'completed';

                  return (
                    <li
                      key={task.id}
                      className="flex flex-col justify-between gap-4 p-4 transition-colors hover:bg-slate-50/80 sm:flex-row sm:items-center sm:px-5 dark:hover:bg-zinc-900"
                    >
                      <div className="flex min-w-0 flex-1 items-start gap-3.5">
                        <button
                          type="button"
                          onClick={() => void handleToggleStatus(task)}
                          aria-label={
                            completed
                              ? `Mark "${task.title}" as pending`
                              : `Mark "${task.title}" as completed`
                          }
                          aria-pressed={completed}
                          className={`mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-md border transition-colors ${
                            completed
                              ? 'border-emerald-600 bg-emerald-600 text-white dark:border-emerald-500 dark:bg-emerald-500'
                              : 'border-slate-300 bg-white text-transparent hover:border-blue-600 dark:border-zinc-700 dark:bg-zinc-950 dark:hover:border-blue-400'
                          }`}
                        >
                          <Check className="h-3.5 w-3.5" strokeWidth={2.5} aria-hidden="true" />
                        </button>

                        <div className="min-w-0 flex-1">
                          <button
                            type="button"
                            onClick={() => setDetailTask(task)}
                            className={`text-left text-sm font-semibold transition-colors hover:text-blue-600 dark:hover:text-blue-400 ${
                              completed
                                ? 'text-slate-400 line-through dark:text-zinc-500'
                                : 'text-slate-950 dark:text-zinc-50'
                            }`}
                          >
                            {task.title}
                          </button>

                          {task.description && (
                            <p className="mt-1 line-clamp-1 text-xs text-slate-600 dark:text-zinc-400">
                              {task.description}
                            </p>
                          )}

                          {/* Clean unboxed metadata with typographic separators */}
                          <div className="mt-2 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-xs text-slate-500 dark:text-zinc-400">
                            <span className="inline-flex items-center gap-1 font-medium">
                              {completed ? (
                                <>
                                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                                  <span className="text-emerald-700 dark:text-emerald-400">
                                    Completed
                                  </span>
                                </>
                              ) : (
                                <>
                                  <Clock className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
                                  <span className="text-amber-700 dark:text-amber-400">
                                    Pending
                                  </span>
                                </>
                              )}
                            </span>

                            <span aria-hidden="true">·</span>

                            <span className="inline-flex items-center gap-1 font-medium">
                              {task.priority === 'High' ? (
                                <AlertTriangle className="h-3.5 w-3.5 text-red-600 dark:text-red-400" />
                              ) : (
                                <Flag
                                  className={`h-3.5 w-3.5 ${
                                    task.priority === 'Medium'
                                      ? 'text-amber-600 dark:text-amber-400'
                                      : 'text-emerald-600 dark:text-emerald-400'
                                  }`}
                                />
                              )}
                              <span>{task.priority} Priority</span>
                            </span>

                            <span aria-hidden="true">·</span>

                            <span
                              className={`inline-flex items-center gap-1 font-mono tabular-nums ${
                                overdue ? 'font-semibold text-red-600 dark:text-red-400' : ''
                              }`}
                            >
                              <Calendar className="h-3.5 w-3.5" aria-hidden="true" />
                              <span>{task.dueDate}</span>
                              {overdue && <span>(Overdue)</span>}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Row actions */}
                      <div className="flex shrink-0 items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => setDetailTask(task)}
                          aria-label={`View details for ${task.title}`}
                          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-transparent text-slate-500 transition-colors hover:border-slate-200 hover:bg-white hover:text-slate-900 dark:text-zinc-400 dark:hover:border-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-white"
                        >
                          <Eye className="h-4 w-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => {
                            setEditingTask(task);
                            setFormOpen(true);
                          }}
                          aria-label={`Edit ${task.title}`}
                          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-transparent text-slate-500 transition-colors hover:border-slate-200 hover:bg-white hover:text-blue-600 dark:text-zinc-400 dark:hover:border-zinc-700 dark:hover:bg-zinc-800 dark:hover:text-blue-400"
                        >
                          <Edit3 className="h-4 w-4" />
                        </button>

                        <button
                          type="button"
                          onClick={() => setDeletingTask(task)}
                          aria-label={`Delete ${task.title}`}
                          className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-transparent text-slate-500 transition-colors hover:border-red-200 hover:bg-red-50 hover:text-red-600 dark:text-zinc-400 dark:hover:border-red-900/60 dark:hover:bg-red-950/40 dark:hover:text-red-400"
                        >
                          <Trash2 className="h-4 w-4" />
                        </button>
                      </div>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </main>
      </div>

      {/* Modals */}
      <TaskFormModal
        open={formOpen}
        editingTask={editingTask}
        onClose={() => {
          setFormOpen(false);
          setEditingTask(null);
        }}
        onSubmit={handleSaveTask}
      />

      <TaskDetailModal
        task={detailTask}
        onClose={() => setDetailTask(null)}
        onEdit={(task) => {
          setEditingTask(task);
          setFormOpen(true);
        }}
        onToggleStatus={(task) => void handleToggleStatus(task)}
        onDelete={(task) => setDeletingTask(task)}
      />

      <DeleteConfirmModal
        task={deletingTask}
        deleting={deletingInFlight}
        onCancel={() => setDeletingTask(null)}
        onConfirm={handleConfirmDelete}
      />
    </div>
  );
}

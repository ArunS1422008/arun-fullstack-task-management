import {Calendar, CheckCircle2, Clock, Edit3, Flag, Trash2, X} from 'lucide-react';
import {useEffect} from 'react';
import type {TaskItem} from '../types/task.ts';

interface TaskDetailModalProps {
  task: TaskItem | null;
  onClose: () => void;
  onEdit: (task: TaskItem) => void;
  onToggleStatus: (task: TaskItem) => void;
  onDelete: (task: TaskItem) => void;
}

export function TaskDetailModal({
  task,
  onClose,
  onEdit,
  onToggleStatus,
  onDelete,
}: TaskDetailModalProps) {
  useEffect(() => {
    if (!task) {
      return;
    }
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [task, onClose]);

  if (!task) {
    return null;
  }

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="task-detail-title"
      className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/65 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="max-h-[90vh] w-full max-w-lg overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl dark:border-zinc-800 dark:bg-zinc-950"
        onClick={(event) => event.stopPropagation()}
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-zinc-800">
          <div>
            <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-500 dark:text-zinc-400">
              <span className="inline-flex items-center gap-1">
                {task.status === 'completed' ? (
                  <CheckCircle2 className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400" />
                ) : (
                  <Clock className="h-3.5 w-3.5 text-amber-600 dark:text-amber-400" />
                )}
                <span>{task.status === 'completed' ? 'Completed' : 'Pending'}</span>
              </span>
              <span aria-hidden="true">·</span>
              <span className="inline-flex items-center gap-1">
                <Flag
                  className={`h-3.5 w-3.5 ${
                    task.priority === 'High'
                      ? 'text-red-600 dark:text-red-400'
                      : task.priority === 'Medium'
                        ? 'text-amber-600 dark:text-amber-400'
                        : 'text-emerald-600 dark:text-emerald-400'
                  }`}
                />
                <span>{task.priority} Priority</span>
              </span>
            </div>

            <h2
              id="task-detail-title"
              className="mt-2 text-xl font-semibold text-slate-950 dark:text-zinc-50"
            >
              {task.title}
            </h2>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close task details"
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900 dark:text-zinc-400 dark:hover:bg-zinc-900 dark:hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-5 space-y-5">
          <div>
            <h3 className="text-xs font-semibold text-slate-500 dark:text-zinc-400">Description</h3>
            <p className="mt-1.5 whitespace-pre-wrap text-sm leading-relaxed text-slate-700 dark:text-zinc-300">
              {task.description || 'No additional description provided for this task.'}
            </p>
          </div>

          <div className="grid grid-cols-2 gap-4 rounded-xl border border-slate-200 bg-slate-50 p-4 dark:border-zinc-800 dark:bg-zinc-900/60">
            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-zinc-400">Due Date</p>
              <p className="mt-1 inline-flex items-center gap-1.5 font-mono text-sm font-medium tabular-nums text-slate-900 dark:text-zinc-100">
                <Calendar className="h-3.5 w-3.5 text-slate-400" aria-hidden="true" />
                <span>{task.dueDate}</span>
              </p>
            </div>
            <div>
              <p className="text-xs font-medium text-slate-500 dark:text-zinc-400">Last Updated</p>
              <p className="mt-1 font-mono text-sm tabular-nums text-slate-900 dark:text-zinc-100">
                {new Date(task.updatedAt).toLocaleDateString()}
              </p>
            </div>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 pt-4 dark:border-zinc-800">
          <button
            type="button"
            onClick={() => {
              onClose();
              onDelete(task);
            }}
            className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2 text-xs font-semibold text-red-700 hover:bg-red-100 dark:border-red-900/60 dark:bg-red-950/30 dark:text-red-300 dark:hover:bg-red-950/60"
          >
            <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
            <span>Delete</span>
          </button>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              type="button"
              onClick={() => {
                onToggleStatus(task);
                onClose();
              }}
              className="inline-flex min-h-10 items-center gap-1.5 rounded-lg border border-slate-300 bg-white px-3.5 py-2 text-xs font-semibold text-slate-800 hover:bg-slate-50 dark:border-zinc-700 dark:bg-zinc-900 dark:text-zinc-100 dark:hover:bg-zinc-800"
            >
              <CheckCircle2 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>{task.status === 'completed' ? 'Mark Pending' : 'Mark Completed'}</span>
            </button>

            <button
              type="button"
              onClick={() => {
                onClose();
                onEdit(task);
              }}
              className="inline-flex min-h-10 items-center gap-1.5 rounded-lg bg-blue-600 px-4 py-2 text-xs font-semibold text-white hover:bg-blue-700 dark:bg-blue-500 dark:hover:bg-blue-600"
            >
              <Edit3 className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Edit Task</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

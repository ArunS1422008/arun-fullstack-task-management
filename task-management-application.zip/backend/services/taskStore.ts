import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import {isMongoConnected} from '../config/db.ts';
import {TaskModel} from '../models/Task.ts';
import {UserModel} from '../models/User.ts';
import type {
  AuthUser,
  TaskFormPayload,
  TaskItem,
  TaskPriority,
  TaskSortOrder,
  TaskStatus,
} from '../../src/types/task.ts';

interface StoredUserRecord {
  id: string;
  name: string;
  email: string;
  passwordHash: string;
  createdAt: string;
}

interface FallbackTaskDB {
  users: StoredUserRecord[];
  tasks: TaskItem[];
}

const FALLBACK_FILE = path.resolve('/tmp', 'arun-taskmanager-preview-db.json');

let memoryDb: FallbackTaskDB = {
  users: [],
  tasks: [],
};

async function persistFallbackDb(): Promise<void> {
  try {
    await fs.writeFile(FALLBACK_FILE, JSON.stringify(memoryDb, null, 2), 'utf8');
  } catch (err) {
    console.warn('[Store] Failed to persist fallback DB:', err instanceof Error ? err.message : err);
  }
}

export async function initializeTaskStore(): Promise<void> {
  if (isMongoConnected()) {
    return;
  }
  try {
    const raw = await fs.readFile(FALLBACK_FILE, 'utf8');
    const parsed = JSON.parse(raw) as Partial<FallbackTaskDB>;
    if (Array.isArray(parsed.users) && Array.isArray(parsed.tasks)) {
      memoryDb = {
        users: parsed.users,
        tasks: parsed.tasks,
      };
    }
  } catch {
    await persistFallbackDb();
  }
}

function toAuthUser(user: {id: string; name: string; email: string; createdAt?: string | Date}): AuthUser {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    createdAt:
      user.createdAt instanceof Date
        ? user.createdAt.toISOString()
        : user.createdAt || new Date().toISOString(),
  };
}

export async function registerUser(input: {
  name: string;
  email: string;
  password: string;
}): Promise<{user?: AuthUser; conflict?: boolean}> {
  const normalizedEmail = input.email.trim().toLowerCase();
  const passwordHash = await bcrypt.hash(input.password, 12);

  if (isMongoConnected()) {
    const existing = await UserModel.findOne({email: normalizedEmail}).lean();
    if (existing) {
      return {conflict: true};
    }

    const created = await UserModel.create({
      name: input.name.trim(),
      email: normalizedEmail,
      passwordHash,
    });

    return {
      user: toAuthUser({
        id: String(created._id),
        name: created.name,
        email: created.email,
        createdAt: created.createdAt,
      }),
    };
  }

  const exists = memoryDb.users.some((u) => u.email === normalizedEmail);
  if (exists) {
    return {conflict: true};
  }

  const newUser: StoredUserRecord = {
    id: crypto.randomUUID(),
    name: input.name.trim(),
    email: normalizedEmail,
    passwordHash,
    createdAt: new Date().toISOString(),
  };
  memoryDb.users.push(newUser);
  await persistFallbackDb();

  return {user: toAuthUser(newUser)};
}

export async function authenticateUser(input: {
  email: string;
  password: string;
}): Promise<AuthUser | null> {
  const normalizedEmail = input.email.trim().toLowerCase();

  if (isMongoConnected()) {
    const userDoc = await UserModel.findOne({email: normalizedEmail});
    if (!userDoc) {
      return null;
    }
    const matches = await bcrypt.compare(input.password, userDoc.passwordHash);
    if (!matches) {
      return null;
    }
    return toAuthUser({
      id: String(userDoc._id),
      name: userDoc.name,
      email: userDoc.email,
      createdAt: userDoc.createdAt,
    });
  }

  const userRecord = memoryDb.users.find((u) => u.email === normalizedEmail);
  if (!userRecord) {
    return null;
  }
  const matches = await bcrypt.compare(input.password, userRecord.passwordHash);
  if (!matches) {
    return null;
  }
  return toAuthUser(userRecord);
}

export async function findUserById(userId: string): Promise<AuthUser | null> {
  if (isMongoConnected()) {
    const doc = await UserModel.findById(userId).select('-passwordHash').lean();
    if (!doc) {
      return null;
    }
    return toAuthUser({
      id: String(doc._id),
      name: doc.name,
      email: doc.email,
      createdAt: doc.createdAt,
    });
  }

  const found = memoryDb.users.find((u) => u.id === userId);
  return found ? toAuthUser(found) : null;
}

function mapMongoTask(doc: {
  _id: unknown;
  userId: unknown;
  title: string;
  description: string;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate: Date;
  createdAt: Date;
  updatedAt: Date;
}): TaskItem {
  return {
    id: String(doc._id),
    userId: String(doc.userId),
    title: doc.title,
    description: doc.description || '',
    priority: doc.priority,
    status: doc.status,
    dueDate: doc.dueDate.toISOString().slice(0, 10),
    createdAt: doc.createdAt.toISOString(),
    updatedAt: doc.updatedAt.toISOString(),
  };
}

export interface TaskQueryOptions {
  status?: TaskStatus;
  priority?: TaskPriority;
  search?: string;
  sort?: TaskSortOrder;
}

export async function listUserTasks(
  userId: string,
  options: TaskQueryOptions = {},
): Promise<TaskItem[]> {
  if (isMongoConnected()) {
    const filter: Record<string, unknown> = {userId};
    if (options.status) {
      filter.status = options.status;
    }
    if (options.priority) {
      filter.priority = options.priority;
    }
    if (options.search) {
      const escaped = options.search.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      filter.$or = [
        {title: {$regex: escaped, $options: 'i'}},
        {description: {$regex: escaped, $options: 'i'}},
      ];
    }

    const sortSpec: Record<string, 1 | -1> =
      options.sort === 'due-desc'
        ? {dueDate: -1, createdAt: -1}
        : options.sort === 'updated-desc'
          ? {updatedAt: -1}
          : {dueDate: 1, createdAt: -1};

    const docs = await TaskModel.find(filter).sort(sortSpec).lean();
    return docs.map((doc) => mapMongoTask(doc));
  }

  let items = memoryDb.tasks.filter((task) => task.userId === userId);

  if (options.status) {
    items = items.filter((task) => task.status === options.status);
  }
  if (options.priority) {
    items = items.filter((task) => task.priority === options.priority);
  }
  if (options.search) {
    const query = options.search.toLowerCase();
    items = items.filter(
      (task) =>
        task.title.toLowerCase().includes(query) ||
        task.description.toLowerCase().includes(query),
    );
  }

  return [...items].sort((a, b) => {
    if (options.sort === 'due-desc') {
      return b.dueDate.localeCompare(a.dueDate);
    }
    if (options.sort === 'updated-desc') {
      return b.updatedAt.localeCompare(a.updatedAt);
    }
    return a.dueDate.localeCompare(b.dueDate);
  });
}

export async function createTaskForUser(
  userId: string,
  payload: TaskFormPayload,
): Promise<TaskItem> {
  if (isMongoConnected()) {
    const created = await TaskModel.create({
      userId,
      title: payload.title.trim(),
      description: payload.description.trim(),
      priority: payload.priority,
      status: payload.status || 'pending',
      dueDate: new Date(`${payload.dueDate}T00:00:00.000Z`),
    });
    return mapMongoTask(created);
  }

  const now = new Date().toISOString();
  const task: TaskItem = {
    id: crypto.randomUUID(),
    userId,
    title: payload.title.trim(),
    description: payload.description.trim(),
    priority: payload.priority,
    status: payload.status || 'pending',
    dueDate: payload.dueDate,
    createdAt: now,
    updatedAt: now,
  };

  memoryDb.tasks.unshift(task);
  await persistFallbackDb();
  return task;
}

export type OwnershipResult<T> =
  | {outcome: 'ok'; data: T}
  | {outcome: 'not_found'}
  | {outcome: 'forbidden'};

export async function getTaskForUser(
  taskId: string,
  userId: string,
): Promise<OwnershipResult<TaskItem>> {
  if (isMongoConnected()) {
    const doc = await TaskModel.findById(taskId).lean();
    if (!doc) {
      return {outcome: 'not_found'};
    }
    if (String(doc.userId) !== userId) {
      return {outcome: 'forbidden'};
    }
    return {outcome: 'ok', data: mapMongoTask(doc)};
  }

  const found = memoryDb.tasks.find((task) => task.id === taskId);
  if (!found) {
    return {outcome: 'not_found'};
  }
  if (found.userId !== userId) {
    return {outcome: 'forbidden'};
  }
  return {outcome: 'ok', data: found};
}

export async function updateTaskForUser(
  taskId: string,
  userId: string,
  updates: Partial<TaskFormPayload>,
): Promise<OwnershipResult<TaskItem>> {
  if (isMongoConnected()) {
    const doc = await TaskModel.findById(taskId);
    if (!doc) {
      return {outcome: 'not_found'};
    }
    if (String(doc.userId) !== userId) {
      return {outcome: 'forbidden'};
    }

    if (updates.title !== undefined) {
      doc.title = updates.title.trim();
    }
    if (updates.description !== undefined) {
      doc.description = updates.description.trim();
    }
    if (updates.priority !== undefined) {
      doc.priority = updates.priority;
    }
    if (updates.status !== undefined) {
      doc.status = updates.status;
    }
    if (updates.dueDate !== undefined) {
      doc.dueDate = new Date(`${updates.dueDate}T00:00:00.000Z`);
    }

    await doc.save();
    return {outcome: 'ok', data: mapMongoTask(doc)};
  }

  const index = memoryDb.tasks.findIndex((task) => task.id === taskId);
  if (index === -1) {
    return {outcome: 'not_found'};
  }
  const existing = memoryDb.tasks[index];
  if (existing.userId !== userId) {
    return {outcome: 'forbidden'};
  }

  const updated: TaskItem = {
    ...existing,
    title: updates.title !== undefined ? updates.title.trim() : existing.title,
    description:
      updates.description !== undefined ? updates.description.trim() : existing.description,
    priority: updates.priority !== undefined ? updates.priority : existing.priority,
    status: updates.status !== undefined ? updates.status : existing.status,
    dueDate: updates.dueDate !== undefined ? updates.dueDate : existing.dueDate,
    updatedAt: new Date().toISOString(),
  };

  memoryDb.tasks[index] = updated;
  await persistFallbackDb();
  return {outcome: 'ok', data: updated};
}

export async function deleteTaskForUser(
  taskId: string,
  userId: string,
): Promise<OwnershipResult<{id: string}>> {
  if (isMongoConnected()) {
    const doc = await TaskModel.findById(taskId);
    if (!doc) {
      return {outcome: 'not_found'};
    }
    if (String(doc.userId) !== userId) {
      return {outcome: 'forbidden'};
    }
    await doc.deleteOne();
    return {outcome: 'ok', data: {id: taskId}};
  }

  const index = memoryDb.tasks.findIndex((task) => task.id === taskId);
  if (index === -1) {
    return {outcome: 'not_found'};
  }
  if (memoryDb.tasks[index].userId !== userId) {
    return {outcome: 'forbidden'};
  }

  memoryDb.tasks.splice(index, 1);
  await persistFallbackDb();
  return {outcome: 'ok', data: {id: taskId}};
}

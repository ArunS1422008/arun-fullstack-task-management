import 'dotenv/config';
import http from 'node:http';
import {createApiApp} from './app.ts';
import {connectDatabase} from './config/db.ts';
import {attachSocketServer} from './realtime/socketServer.ts';
import {initializeTaskStore} from './services/taskStore.ts';

async function startBackendOnly() {
  await connectDatabase();
  await initializeTaskStore();

  const app = createApiApp();
  const httpServer = http.createServer(app);
  attachSocketServer(httpServer);

  const port = Number(process.env.PORT) || 5000;

  app.get('/', (_req, res) => {
    res.json({
      success: true,
      service: 'TaskFlow API & Socket.IO Server',
      endpoints: ['/api/health', '/api/auth/register', '/api/auth/login', '/api/tasks'],
    });
  });

  httpServer.listen(port, '0.0.0.0', () => {
    console.info(`[Backend API] TaskFlow API listening on http://localhost:${port}`);
  });
}

startBackendOnly().catch((error) => {
  console.error('[Backend Startup Error]', error);
  process.exit(1);
});

import type {NextFunction, Request, Response} from 'express';
import type {
  TaskFormPayload,
  TaskPriority,
  TaskSortOrder,
  TaskStatus,
} from '../../src/types/task.ts';

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const DATE_REGEX = /^\d{4}-\d{2}-\d{2}$/;
const OBJECT_ID_OR_UUID_REGEX = /^([a-f0-9]{24}|[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i;

const VALID_PRIORITIES = new Set<TaskPriority>(['High', 'Medium', 'Low']);
const VALID_STATUSES = new Set<TaskStatus>(['pending', 'completed']);
const VALID_SORTS = new Set<TaskSortOrder>(['due-asc', 'due-desc', 'updated-desc']);

interface RateBucket {
  count: number;
  resetAt: number;
}

const authAttempts = new Map<string, RateBucket>();
const AUTH_WINDOW_MS = 10 * 60 * 1000;
const MAX_AUTH_ATTEMPTS = 25;

export function authRateLimiter(req: Request, res: Response, next: NextFunction): void {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const bucket = authAttempts.get(ip);

  if (!bucket || now > bucket.resetAt) {
    authAttempts.set(ip, {count: 1, resetAt: now + AUTH_WINDOW_MS});
    next();
    return;
  }

  if (bucket.count >= MAX_AUTH_ATTEMPTS) {
    res.status(429).json({
      success: false,
      message: 'Too many authentication attempts. Please wait a few minutes and try again.',
    });
    return;
  }

  bucket.count += 1;
  next();
}

export function isValidTaskId(rawId: unknown): rawId is string {
  return typeof rawId === 'string' && OBJECT_ID_OR_UUID_REGEX.test(rawId.trim());
}

export function validateRegisterBody(body: unknown): {
  valid: boolean;
  data?: {name: string; email: string; password: string};
  errors?: Record<string, string>;
} {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {valid: false, errors: {form: 'Request body must be a JSON object.'}};
  }

  const raw = body as Record<string, unknown>;
  const errors: Record<string, string> = {};

  if (typeof raw.name !== 'string' || raw.name.trim().length < 2 || raw.name.trim().length > 80) {
    errors.name = 'Name must be between 2 and 80 characters.';
  }

  if (
    typeof raw.email !== 'string' ||
    raw.email.trim().length > 120 ||
    !EMAIL_REGEX.test(raw.email.trim())
  ) {
    errors.email = 'Please enter a valid email address.';
  }

  if (typeof raw.password !== 'string' || raw.password.length < 6 || raw.password.length > 72) {
    errors.password = 'Password must be between 6 and 72 characters.';
  }

  if (Object.keys(errors).length > 0) {
    return {valid: false, errors};
  }

  return {
    valid: true,
    data: {
      name: (raw.name as string).trim(),
      email: (raw.email as string).trim().toLowerCase(),
      password: raw.password as string,
    },
  };
}

export function validateLoginBody(body: unknown): {
  valid: boolean;
  data?: {email: string; password: string};
  errors?: Record<string, string>;
} {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {valid: false, errors: {form: 'Request body must be a JSON object.'}};
  }

  const raw = body as Record<string, unknown>;
  const errors: Record<string, string> = {};

  if (typeof raw.email !== 'string' || !EMAIL_REGEX.test(raw.email.trim())) {
    errors.email = 'Please enter a valid email address.';
  }

  if (typeof raw.password !== 'string' || raw.password.length < 1 || raw.password.length > 72) {
    errors.password = 'Password is required.';
  }

  if (Object.keys(errors).length > 0) {
    return {valid: false, errors};
  }

  return {
    valid: true,
    data: {
      email: (raw.email as string).trim().toLowerCase(),
      password: raw.password as string,
    },
  };
}

export function validateTaskCreateBody(body: unknown): {
  valid: boolean;
  data?: TaskFormPayload;
  errors?: Record<string, string>;
} {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {valid: false, errors: {form: 'Request body must be a JSON object.'}};
  }

  const raw = body as Record<string, unknown>;
  const errors: Record<string, string> = {};

  if (typeof raw.title !== 'string' || raw.title.trim().length < 2 || raw.title.trim().length > 120) {
    errors.title = 'Task title must be between 2 and 120 characters.';
  }

  if (raw.description !== undefined && typeof raw.description !== 'string') {
    errors.description = 'Description must be plain text.';
  } else if (typeof raw.description === 'string' && raw.description.trim().length > 1000) {
    errors.description = 'Description cannot exceed 1000 characters.';
  }

  if (typeof raw.priority !== 'string' || !VALID_PRIORITIES.has(raw.priority as TaskPriority)) {
    errors.priority = 'Priority must be High, Medium, or Low.';
  }

  if (typeof raw.dueDate !== 'string' || !DATE_REGEX.test(raw.dueDate.trim())) {
    errors.dueDate = 'Please select a valid due date (YYYY-MM-DD).';
  } else {
    const parsedDate = new Date(`${raw.dueDate.trim()}T00:00:00.000Z`);
    if (Number.isNaN(parsedDate.getTime())) {
      errors.dueDate = 'Please enter a valid calendar date.';
    }
  }

  if (raw.status !== undefined) {
    if (typeof raw.status !== 'string' || !VALID_STATUSES.has(raw.status as TaskStatus)) {
      errors.status = 'Status must be pending or completed.';
    }
  }

  if (Object.keys(errors).length > 0) {
    return {valid: false, errors};
  }

  return {
    valid: true,
    data: {
      title: (raw.title as string).trim(),
      description: typeof raw.description === 'string' ? raw.description.trim() : '',
      priority: raw.priority as TaskPriority,
      dueDate: (raw.dueDate as string).trim(),
      status: (raw.status as TaskStatus | undefined) || 'pending',
    },
  };
}

export function validateTaskUpdateBody(body: unknown): {
  valid: boolean;
  data?: Partial<TaskFormPayload>;
  errors?: Record<string, string>;
} {
  if (!body || typeof body !== 'object' || Array.isArray(body)) {
    return {valid: false, errors: {form: 'Request body must be a JSON object.'}};
  }

  const raw = body as Record<string, unknown>;
  const errors: Record<string, string> = {};
  const updates: Partial<TaskFormPayload> = {};

  if (raw.title !== undefined) {
    if (typeof raw.title !== 'string' || raw.title.trim().length < 2 || raw.title.trim().length > 120) {
      errors.title = 'Task title must be between 2 and 120 characters.';
    } else {
      updates.title = raw.title.trim();
    }
  }

  if (raw.description !== undefined) {
    if (typeof raw.description !== 'string' || raw.description.trim().length > 1000) {
      errors.description = 'Description must be plain text under 1000 characters.';
    } else {
      updates.description = raw.description.trim();
    }
  }

  if (raw.priority !== undefined) {
    if (typeof raw.priority !== 'string' || !VALID_PRIORITIES.has(raw.priority as TaskPriority)) {
      errors.priority = 'Priority must be High, Medium, or Low.';
    } else {
      updates.priority = raw.priority as TaskPriority;
    }
  }

  if (raw.status !== undefined) {
    if (typeof raw.status !== 'string' || !VALID_STATUSES.has(raw.status as TaskStatus)) {
      errors.status = 'Status must be pending or completed.';
    } else {
      updates.status = raw.status as TaskStatus;
    }
  }

  if (raw.dueDate !== undefined) {
    if (typeof raw.dueDate !== 'string' || !DATE_REGEX.test(raw.dueDate.trim())) {
      errors.dueDate = 'Due date must be formatted as YYYY-MM-DD.';
    } else {
      const parsedDate = new Date(`${raw.dueDate.trim()}T00:00:00.000Z`);
      if (Number.isNaN(parsedDate.getTime())) {
        errors.dueDate = 'Please enter a valid calendar date.';
      } else {
        updates.dueDate = raw.dueDate.trim();
      }
    }
  }

  if (Object.keys(errors).length > 0) {
    return {valid: false, errors};
  }

  if (Object.keys(updates).length === 0) {
    return {
      valid: false,
      errors: {form: 'At least one task field must be provided for update.'},
    };
  }

  return {valid: true, data: updates};
}

export function parseTaskQueryFilters(query: Record<string, unknown>): {
  status?: TaskStatus;
  priority?: TaskPriority;
  search?: string;
  sort?: TaskSortOrder;
} {
  const result: {
    status?: TaskStatus;
    priority?: TaskPriority;
    search?: string;
    sort?: TaskSortOrder;
  } = {};

  if (typeof query.status === 'string' && VALID_STATUSES.has(query.status as TaskStatus)) {
    result.status = query.status as TaskStatus;
  }
  if (typeof query.priority === 'string' && VALID_PRIORITIES.has(query.priority as TaskPriority)) {
    result.priority = query.priority as TaskPriority;
  }
  if (typeof query.search === 'string' && query.search.trim().length > 0) {
    result.search = query.search.trim().slice(0, 100);
  }
  if (typeof query.sort === 'string' && VALID_SORTS.has(query.sort as TaskSortOrder)) {
    result.sort = query.sort as TaskSortOrder;
  }

  return result;
}

import type {NextFunction, Request, Response} from 'express';
import {verifyAuthToken} from '../config/auth.ts';
import {findUserById} from '../services/taskStore.ts';
import type {AuthUser} from '../../src/types/task.ts';

export interface AuthenticatedRequest extends Request {
  user?: AuthUser;
}

export async function requireAuth(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({
      success: false,
      message: 'Authentication required. Please sign in to continue.',
    });
    return;
  }

  const token = authHeader.slice('Bearer '.length).trim();
  if (!token) {
    res.status(401).json({
      success: false,
      message: 'Authentication token is missing.',
    });
    return;
  }

  try {
    const decoded = verifyAuthToken(token);
    const user = await findUserById(decoded.sub);
    if (!user) {
      res.status(401).json({
        success: false,
        message: 'User account no longer exists. Please sign in again.',
      });
      return;
    }

    req.user = user;
    next();
  } catch {
    res.status(401).json({
      success: false,
      message: 'Your session has expired or is invalid. Please sign in again.',
    });
  }
}

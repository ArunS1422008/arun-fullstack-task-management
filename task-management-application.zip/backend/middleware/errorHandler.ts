import type {NextFunction, Request, Response} from 'express';

export function apiNotFoundHandler(_req: Request, res: Response): void {
  res.status(404).json({
    success: false,
    message: 'Requested API endpoint was not found.',
  });
}

export function globalErrorHandler(
  err: unknown,
  _req: Request,
  res: Response,
  _next: NextFunction,
): void {
  if (err instanceof SyntaxError && 'body' in err) {
    res.status(400).json({
      success: false,
      message: 'Malformed JSON request body.',
    });
    return;
  }

  const message = err instanceof Error ? err.message : 'Unexpected server error';
  console.error('[Server Error]', message);

  res.status(500).json({
    success: false,
    message: 'An internal server error occurred. Please try again later.',
  });
}

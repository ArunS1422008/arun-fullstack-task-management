import {Router, type NextFunction, type Response} from 'express';
import {requireAuth, type AuthenticatedRequest} from '../middleware/auth.ts';
import {
  isValidTaskId,
  parseTaskQueryFilters,
  validateTaskCreateBody,
  validateTaskUpdateBody,
} from '../middleware/validate.ts';
import {
  emitTaskCreated,
  emitTaskDeleted,
  emitTaskUpdated,
} from '../realtime/socketServer.ts';
import {
  createTaskForUser,
  deleteTaskForUser,
  getTaskForUser,
  listUserTasks,
  updateTaskForUser,
} from '../services/taskStore.ts';

const router = Router();

router.use(requireAuth);

router.get('/', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const userId = req.user!.id;
    const filters = parseTaskQueryFilters(req.query as Record<string, unknown>);
    const tasks = await listUserTasks(userId, filters);

    res.json({
      success: true,
      count: tasks.length,
      data: tasks,
    });
  } catch (error) {
    next(error);
  }
});

router.get('/:id', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const {id} = req.params;
    if (!isValidTaskId(id)) {
      res.status(400).json({
        success: false,
        message: 'Invalid task identifier format.',
      });
      return;
    }

    const result = await getTaskForUser(id, req.user!.id);
    if (result.outcome === 'not_found') {
      res.status(404).json({success: false, message: 'Task not found.'});
      return;
    }
    if (result.outcome === 'forbidden') {
      res.status(403).json({
        success: false,
        message: 'You do not have permission to access this task.',
      });
      return;
    }

    res.json({
      success: true,
      data: result.data,
    });
  } catch (error) {
    next(error);
  }
});

router.post('/', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const validation = validateTaskCreateBody(req.body);
    if (!validation.valid || !validation.data) {
      res.status(400).json({
        success: false,
        message: 'Please correct the task fields and try again.',
        errors: validation.errors,
      });
      return;
    }

    const userId = req.user!.id;
    const created = await createTaskForUser(userId, validation.data);
    emitTaskCreated(userId, created);

    res.status(201).json({
      success: true,
      message: 'Task created successfully.',
      data: created,
    });
  } catch (error) {
    next(error);
  }
});

async function handleTaskUpdate(
  req: AuthenticatedRequest,
  res: Response,
  next: NextFunction,
): Promise<void> {
  try {
    const {id} = req.params;
    if (!isValidTaskId(id)) {
      res.status(400).json({
        success: false,
        message: 'Invalid task identifier format.',
      });
      return;
    }

    const validation = validateTaskUpdateBody(req.body);
    if (!validation.valid || !validation.data) {
      res.status(400).json({
        success: false,
        message: 'Please check your task updates and try again.',
        errors: validation.errors,
      });
      return;
    }

    const userId = req.user!.id;
    const result = await updateTaskForUser(id, userId, validation.data);
    if (result.outcome === 'not_found') {
      res.status(404).json({success: false, message: 'Task not found.'});
      return;
    }
    if (result.outcome === 'forbidden') {
      res.status(403).json({
        success: false,
        message: 'You do not have permission to update this task.',
      });
      return;
    }

    emitTaskUpdated(userId, result.data);

    res.json({
      success: true,
      message: 'Task updated successfully.',
      data: result.data,
    });
  } catch (error) {
    next(error);
  }
}

router.put('/:id', handleTaskUpdate);
router.patch('/:id', handleTaskUpdate);

router.delete('/:id', async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
  try {
    const {id} = req.params;
    if (!isValidTaskId(id)) {
      res.status(400).json({
        success: false,
        message: 'Invalid task identifier format.',
      });
      return;
    }

    const userId = req.user!.id;
    const result = await deleteTaskForUser(id, userId);
    if (result.outcome === 'not_found') {
      res.status(404).json({success: false, message: 'Task not found.'});
      return;
    }
    if (result.outcome === 'forbidden') {
      res.status(403).json({
        success: false,
        message: 'You do not have permission to delete this task.',
      });
      return;
    }

    emitTaskDeleted(userId, id);

    res.json({
      success: true,
      message: 'Task deleted successfully.',
      deletedId: id,
    });
  } catch (error) {
    next(error);
  }
});

export default router;

import {Router, type NextFunction, type Request, type Response} from 'express';
import {signAuthToken} from '../config/auth.ts';
import {requireAuth, type AuthenticatedRequest} from '../middleware/auth.ts';
import {authRateLimiter, validateLoginBody, validateRegisterBody} from '../middleware/validate.ts';
import {authenticateUser, registerUser} from '../services/taskStore.ts';

const router = Router();

router.post('/register', authRateLimiter, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const validation = validateRegisterBody(req.body);
    if (!validation.valid || !validation.data) {
      res.status(400).json({
        success: false,
        message: 'Please correct the highlighted registration fields.',
        errors: validation.errors,
      });
      return;
    }

    const result = await registerUser(validation.data);
    if (result.conflict || !result.user) {
      res.status(409).json({
        success: false,
        message: 'An account with this email address already exists.',
        errors: {email: 'This email is already registered.'},
      });
      return;
    }

    const token = signAuthToken({
      sub: result.user.id,
      email: result.user.email,
      name: result.user.name,
    });

    res.status(201).json({
      success: true,
      message: 'Account created successfully.',
      token,
      user: result.user,
    });
  } catch (error) {
    next(error);
  }
});

router.post('/login', authRateLimiter, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const validation = validateLoginBody(req.body);
    if (!validation.valid || !validation.data) {
      res.status(400).json({
        success: false,
        message: 'Please enter a valid email and password.',
        errors: validation.errors,
      });
      return;
    }

    const user = await authenticateUser(validation.data);
    if (!user) {
      res.status(401).json({
        success: false,
        message: 'Invalid email address or password.',
      });
      return;
    }

    const token = signAuthToken({
      sub: user.id,
      email: user.email,
      name: user.name,
    });

    res.json({
      success: true,
      message: 'Signed in successfully.',
      token,
      user,
    });
  } catch (error) {
    next(error);
  }
});

router.post('/logout', requireAuth, (_req: AuthenticatedRequest, res: Response) => {
  res.json({
    success: true,
    message: 'Signed out successfully.',
  });
});

router.get('/me', requireAuth, (req: AuthenticatedRequest, res: Response) => {
  res.json({
    success: true,
    user: req.user,
  });
});

export default router;

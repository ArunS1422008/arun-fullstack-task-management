import type {Server as HttpServer} from 'node:http';
import {Server as SocketIOServer} from 'socket.io';
import {verifyAuthToken} from '../config/auth.ts';
import {findUserById} from '../services/taskStore.ts';
import type {TaskItem} from '../../src/types/task.ts';

let ioInstance: SocketIOServer | null = null;

export function attachSocketServer(httpServer: HttpServer): SocketIOServer {
  const allowedOrigins = (process.env.FRONTEND_URL || '')
    .split(',')
    .map((origin) => origin.trim())
    .filter(Boolean);

  const io = new SocketIOServer(httpServer, {
    cors: {
      origin(origin, callback) {
        if (!origin || allowedOrigins.length === 0 || allowedOrigins.includes(origin)) {
          callback(null, true);
          return;
        }
        callback(new Error('Origin not permitted by Socket.IO CORS policy'));
      },
      methods: ['GET', 'POST'],
    },
  });

  io.use(async (socket, next) => {
    try {
      const token =
        typeof socket.handshake.auth?.token === 'string'
          ? socket.handshake.auth.token.trim()
          : '';
      if (!token) {
        next(new Error('Authentication token required'));
        return;
      }
      const decoded = verifyAuthToken(token);
      const user = await findUserById(decoded.sub);
      if (!user) {
        next(new Error('Authenticated user not found'));
        return;
      }
      socket.data.userId = user.id;
      next();
    } catch {
      next(new Error('Invalid or expired session token'));
    }
  });

  io.on('connection', (socket) => {
    const userId = socket.data.userId as string | undefined;
    if (userId) {
      void socket.join(`user:${userId}`);
    }
  });

  ioInstance = io;
  return io;
}

export function emitTaskCreated(userId: string, task: TaskItem): void {
  ioInstance?.to(`user:${userId}`).emit('task:created', {task});
}

export function emitTaskUpdated(userId: string, task: TaskItem): void {
  ioInstance?.to(`user:${userId}`).emit('task:updated', {task});
}

export function emitTaskDeleted(userId: string, taskId: string): void {
  ioInstance?.to(`user:${userId}`).emit('task:deleted', {taskId});
}

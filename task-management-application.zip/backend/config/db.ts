import mongoose from 'mongoose';

let mongoConnected = false;

export function isMongoConnected(): boolean {
  return mongoConnected && mongoose.connection.readyState === 1;
}

export async function connectDatabase(): Promise<boolean> {
  const uri = (process.env.MONGODB_URI || '').trim();

  if (!uri) {
    mongoConnected = false;
    console.info('[DB] MONGODB_URI not configured. Running with local preview storage.');
    return false;
  }

  if (!uri.startsWith('mongodb://') && !uri.startsWith('mongodb+srv://')) {
    mongoConnected = false;
    console.warn('[DB] Invalid MONGODB_URI format. Falling back to local preview storage.');
    return false;
  }

  try {
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 5000,
    });
    mongoConnected = true;
    console.info('[DB] Connected to MongoDB successfully.');

    mongoose.connection.on('disconnected', () => {
      mongoConnected = false;
    });
    mongoose.connection.on('reconnected', () => {
      mongoConnected = true;
    });

    return true;
  } catch (error) {
    mongoConnected = false;
    const message = error instanceof Error ? error.message : 'Unknown connection error';
    console.warn(`[DB] MongoDB connection failed (${message}). Using local preview storage.`);
    return false;
  }
}

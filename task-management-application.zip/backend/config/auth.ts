import crypto from 'node:crypto';
import jwt, {type SignOptions} from 'jsonwebtoken';

const FALLBACK_RUNTIME_SECRET = crypto.randomBytes(32).toString('hex');

export interface JwtPayloadData {
  sub: string;
  email: string;
  name: string;
}

export function getJwtSecret(): string {
  const configured = (process.env.JWT_SECRET || '').trim();
  return configured || FALLBACK_RUNTIME_SECRET;
}

export function signAuthToken(payload: JwtPayloadData): string {
  const expiresIn = (process.env.JWT_EXPIRES_IN || '7d').trim() as SignOptions['expiresIn'];
  return jwt.sign(payload, getJwtSecret(), {expiresIn});
}

export function verifyAuthToken(token: string): JwtPayloadData {
  const decoded = jwt.verify(token, getJwtSecret());
  if (!decoded || typeof decoded !== 'object' || typeof decoded.sub !== 'string') {
    throw new Error('Invalid token payload');
  }
  return {
    sub: decoded.sub,
    email: typeof decoded.email === 'string' ? decoded.email : '',
    name: typeof decoded.name === 'string' ? decoded.name : '',
  };
}

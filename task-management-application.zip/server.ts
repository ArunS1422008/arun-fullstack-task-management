import 'dotenv/config';
import express from 'express';
import http from 'node:http';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createServer as createViteServer} from 'vite';
import {createApiApp} from './backend/app.ts';
import {connectDatabase} from './backend/config/db.ts';
import {attachSocketServer} from './backend/realtime/socketServer.ts';
import {initializeTaskStore} from './backend/services/taskStore.ts';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  await connectDatabase();
  await initializeTaskStore();

  const app = createApiApp();
  const httpServer = http.createServer(app);
  attachSocketServer(httpServer);

  const port = Number(process.env.PORT) || 3000;
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const vite = await createViteServer({
      server: {middlewareMode: true},
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(__dirname, 'dist');
    app.use(express.static(distDir));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  httpServer.listen(port, '0.0.0.0', () => {
    console.info(`[Server] TaskFlow listening on http://localhost:${port}`);
  });
}

startServer().catch((error) => {
  console.error('[Startup Error]', error);
  process.exit(1);
});
